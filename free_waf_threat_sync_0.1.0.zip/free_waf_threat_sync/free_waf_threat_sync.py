#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Free WAF Threat Intelligence Sync

Safely synchronise selected public IPv4 threat feeds into the legacy Baota
free_waf JSON range format. Standard-library only; dry-run is the default.
"""

from __future__ import print_function

import argparse
import copy
import datetime as dt
import fcntl
import ipaddress
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

VERSION = "0.1.0"
DEFAULT_CONFIG = "/etc/free-waf-threat-sync/config.json"
IPV4_TOKEN_RE = re.compile(r"(?<![0-9A-Fa-f:.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?:/[0-9]{1,2})?(?![0-9A-Fa-f:.])")


def utc_now():
    return dt.datetime.now(dt.timezone.utc)


def iso_now():
    return utc_now().replace(microsecond=0).isoformat()


def parse_iso(value):
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return parsed
    except Exception:
        return None


def setup_logging(path):
    logger = logging.getLogger("free_waf_threat_sync")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as exc:
        logger.warning("无法打开日志文件 %s：%s", path, exc)
    return logger


def read_json(path, default=None):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json_atomic(path, value, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=path.name + ".tmp.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_path, mode)
        os.replace(temp_path, str(path))
        try:
            dir_fd = os.open(str(path.parent), os.O_DIRECTORY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            pass
    except Exception:
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise


def file_mode(path, fallback=0o600):
    try:
        return os.stat(path).st_mode & 0o777
    except OSError:
        return fallback


def range_to_pair(start, end):
    return (int(start), int(end))


def ip_to_octets(value):
    ip = ipaddress.IPv4Address(value)
    return list(ip.packed)


def pair_to_waf_rule(pair):
    start, end = pair
    return [ip_to_octets(start), ip_to_octets(end)]


def waf_rule_to_pair(rule, index=None):
    label = "第 %s 条" % (index + 1) if index is not None else "规则"
    if not isinstance(rule, list) or len(rule) != 2:
        raise ValueError("%s不是 [起始IP, 结束IP] 结构" % label)
    octet_lists = []
    for endpoint in rule:
        if not isinstance(endpoint, list) or len(endpoint) != 4:
            raise ValueError("%s的IP端点不是4个字节" % label)
        if any((not isinstance(n, int)) or isinstance(n, bool) or n < 0 or n > 255 for n in endpoint):
            raise ValueError("%s包含无效IP字节" % label)
        octet_lists.append(endpoint)
    start = int(ipaddress.IPv4Address(bytes(octet_lists[0])))
    end = int(ipaddress.IPv4Address(bytes(octet_lists[1])))
    if start > end:
        raise ValueError("%s起始IP大于结束IP" % label)
    return (start, end)


def parse_waf_file(path):
    data = read_json(path)
    if not isinstance(data, list):
        raise ValueError("WAF JSON 顶层必须是数组")
    pairs = []
    for index, rule in enumerate(data):
        pairs.append(waf_rule_to_pair(rule, index))
    return pairs


def pair_key(pair):
    return (int(pair[0]), int(pair[1]))


def encode_pairs(pairs):
    return [pair_to_waf_rule(pair) for pair in pairs]


def dedupe_pairs(pairs):
    seen = set()
    result = []
    for pair in pairs:
        key = pair_key(pair)
        if key not in seen:
            seen.add(key)
            result.append(key)
    return result


def pair_to_cidrs(pair):
    start = ipaddress.IPv4Address(pair[0])
    end = ipaddress.IPv4Address(pair[1])
    return list(ipaddress.summarize_address_range(start, end))


def collapse_pairs(pairs):
    networks = []
    for pair in pairs:
        networks.extend(pair_to_cidrs(pair))
    if not networks:
        return []
    collapsed = list(ipaddress.collapse_addresses(networks))
    return [(int(net.network_address), int(net.broadcast_address)) for net in collapsed]


def ranges_from_config(values, label):
    ranges = []
    for value in values or []:
        try:
            net = ipaddress.ip_network(str(value).strip(), strict=False)
            if net.version != 4:
                raise ValueError("只支持IPv4")
            ranges.append((int(net.network_address), int(net.broadcast_address)))
        except Exception as exc:
            raise ValueError("配置项 %s 中的地址无效：%r (%s)" % (label, value, exc))
    return ranges


def merge_intervals(intervals):
    if not intervals:
        return []
    ordered = sorted((int(a), int(b)) for a, b in intervals)
    result = []
    cur_a, cur_b = ordered[0]
    for start, end in ordered[1:]:
        if start <= cur_b + 1:
            if end > cur_b:
                cur_b = end
        else:
            result.append((cur_a, cur_b))
            cur_a, cur_b = start, end
    result.append((cur_a, cur_b))
    return result


def subtract_intervals(base_pair, exclusions):
    start, end = base_pair
    cursor = start
    fragments = []
    for ex_start, ex_end in exclusions:
        if ex_end < cursor:
            continue
        if ex_start > end:
            break
        if ex_start > cursor:
            fragments.append((cursor, min(end, ex_start - 1)))
        cursor = max(cursor, ex_end + 1)
        if cursor > end:
            break
    if cursor <= end:
        fragments.append((cursor, end))
    return fragments


def global_ipv4_network(network):
    # Require both edges to be globally routable; this rejects private,
    # loopback, link-local, multicast, unspecified and reserved ranges.
    return bool(network.network_address.is_global and network.broadcast_address.is_global)


def normalize_feed_text(text, source_id, policy):
    min_prefix = int(policy.get("min_prefix_length", 20))
    max_entries = int(policy.get("max_entries_per_source", 250000))
    networks = set()
    invalid = 0
    ipv6_seen = 0
    broad_skipped = 0
    non_global_skipped = 0

    for match in IPV4_TOKEN_RE.finditer(text):
        token = match.group(0)
        try:
            network = ipaddress.ip_network(token, strict=False)
            if network.version != 4:
                ipv6_seen += 1
                continue
            if network.prefixlen < min_prefix:
                broad_skipped += 1
                continue
            if not global_ipv4_network(network):
                non_global_skipped += 1
                continue
            networks.add(str(network))
            if len(networks) > max_entries:
                raise ValueError("来源 %s 超过单源最大记录数 %s，拒绝处理" % (source_id, max_entries))
        except ValueError as exc:
            if "超过单源最大记录数" in str(exc):
                raise
            invalid += 1

    ordered = sorted(networks, key=lambda item: (int(ipaddress.ip_network(item).network_address), ipaddress.ip_network(item).prefixlen))
    stats = {
        "accepted": len(ordered),
        "invalid": invalid,
        "broad_skipped": broad_skipped,
        "non_global_skipped": non_global_skipped,
        "ipv6_ignored": ipv6_seen,
    }
    return ordered, stats


def fetch_url(url, timeout=25, max_bytes=12 * 1024 * 1024):
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "FreeWAF-Threat-Intelligence-Sync/%s (defensive feed consumer)" % VERSION,
            "Accept": "text/plain, */*;q=0.8",
            "Accept-Encoding": "identity",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        status = getattr(response, "status", 200)
        if status != 200:
            raise RuntimeError("HTTP 状态码 %s" % status)
        data = response.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise RuntimeError("下载超过大小限制（%s bytes）" % max_bytes)
        content_type = response.headers.get("Content-Type", "")
        if "text/html" in content_type.lower():
            raise RuntimeError("服务器返回 HTML 页面，不是名单文件")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("latin-1")


def load_config(path):
    config = read_json(path)
    for section in ("waf", "paths", "policy", "sources"):
        if section not in config or not isinstance(config[section], dict):
            raise ValueError("配置文件缺少对象：%s" % section)
    return config


def source_due(source_state, refresh_minutes, now):
    if not source_state or not source_state.get("last_success"):
        return True
    last = parse_iso(source_state.get("last_success"))
    if not last:
        return True
    return (now - last).total_seconds() >= int(refresh_minutes) * 60


def collect_sources(config, state, logger):
    now = utc_now()
    policy = config["policy"]
    old_sources = state.get("sources", {}) if isinstance(state, dict) else {}
    new_sources = copy.deepcopy(old_sources)
    source_networks = {}
    source_reports = []
    failures = []
    stale_limit = int(policy.get("max_stale_hours", 168))

    for source_id, source in config["sources"].items():
        if not source.get("enabled", True):
            continue
        cached = old_sources.get(source_id, {})
        interval = int(source.get("refresh_minutes", 30))
        required = bool(source.get("required", False))
        should_fetch = source_due(cached, interval, now)
        report = {"id": source_id, "name": source.get("name", source_id), "required": required}

        if not should_fetch:
            source_networks[source_id] = list(cached.get("networks", []))
            report.update({"status": "使用缓存", "accepted": len(source_networks[source_id]), "last_success": cached.get("last_success")})
            source_reports.append(report)
            continue

        try:
            text = fetch_url(source["url"], int(source.get("timeout", 25)), int(source.get("max_bytes", 12 * 1024 * 1024)))
            networks, stats = normalize_feed_text(text, source_id, policy)
            min_entries = int(source.get("min_entries", 1))
            if len(networks) < min_entries:
                raise RuntimeError("有效记录仅 %s 条，低于安全阈值 %s；可能是源异常或格式变化" % (len(networks), min_entries))
            new_sources[source_id] = {
                "last_success": iso_now(),
                "networks": networks,
                "raw_accepted": len(networks),
                "stats": stats,
                "url": source["url"],
            }
            source_networks[source_id] = networks
            report.update({"status": "下载成功", "accepted": len(networks), "stats": stats})
            logger.info("情报源 %s：成功，保留 %s 个IPv4网络（过滤过宽网段 %s，非全球地址 %s）",
                        source_id, len(networks), stats["broad_skipped"], stats["non_global_skipped"])
        except Exception as exc:
            age_hours = None
            last = parse_iso(cached.get("last_success"))
            if last:
                age_hours = max(0.0, (now - last).total_seconds() / 3600.0)
            if cached.get("networks") and age_hours is not None and age_hours <= stale_limit:
                source_networks[source_id] = list(cached.get("networks", []))
                report.update({"status": "下载失败，沿用缓存", "accepted": len(source_networks[source_id]), "error": str(exc), "cache_age_hours": round(age_hours, 1)})
                logger.warning("情报源 %s 下载失败，沿用 %.1f 小时前缓存：%s", source_id, age_hours, exc)
            else:
                report.update({"status": "下载失败", "accepted": 0, "error": str(exc)})
                logger.error("情报源 %s 下载失败：%s", source_id, exc)
                if required:
                    failures.append("%s：%s" % (source_id, exc))
            if not cached.get("networks"):
                # Optional source without a cache can be skipped; required source aborts apply.
                new_sources.pop(source_id, None)
        source_reports.append(report)

    return source_networks, new_sources, source_reports, failures


def state_pairs(values, key):
    result = []
    for item in values or []:
        if not isinstance(item, list) or len(item) != 2:
            raise ValueError("状态文件中的 %s 格式错误" % key)
        result.append((int(item[0]), int(item[1])))
    return result


def build_manual_rules(current_pairs, state, logger):
    if not state or state.get("schema_version") != 1:
        logger.info("首次运行：现有 %s 条黑名单全部作为人工规则保留", len(current_pairs))
        return dedupe_pairs(current_pairs)

    previous_written = set(state_pairs(state.get("last_written_ranges", []), "last_written_ranges"))
    previous_manual = state_pairs(state.get("manual_ranges", []), "manual_ranges")
    current_set = set(current_pairs)

    # Preserve known manual entries still present in the live WAF file.
    manual = [pair for pair in previous_manual if pair in current_set]
    # Any new live entry not written by our previous run is treated as manual.
    manual.extend(pair for pair in current_pairs if pair not in previous_written)
    manual = dedupe_pairs(manual)
    logger.info("人工规则保护：保留 %s 条；检测到新增人工规则 %s 条", len(manual),
                max(0, len([p for p in current_pairs if p not in previous_written])))
    return manual


def make_auto_pairs(source_networks, config, whitelist_pairs, logger):
    policy = config["policy"]
    max_auto = int(policy.get("max_auto_rules", 25000))
    protect = ranges_from_config(policy.get("protected_ips", []), "policy.protected_ips")
    exclusions = merge_intervals(list(whitelist_pairs) + protect)
    priority = policy.get("source_priority", list(source_networks.keys()))
    accepted_networks = []
    included_sources = []
    skipped_sources = []

    for source_id in priority:
        if source_id not in source_networks:
            continue
        candidate = []
        for item in source_networks[source_id]:
            try:
                net = ipaddress.ip_network(item, strict=False)
                if net.version == 4 and global_ipv4_network(net):
                    candidate.append(net)
            except Exception:
                continue
        combined = list(ipaddress.collapse_addresses(accepted_networks + candidate)) if (accepted_networks or candidate) else []
        if len(combined) > max_auto:
            skipped_sources.append((source_id, len(candidate), len(combined)))
            logger.warning("达到自动规则上限 %s：跳过来源 %s（加入后约 %s 条）", max_auto, source_id, len(combined))
            continue
        accepted_networks = combined
        included_sources.append(source_id)

    # Convert exact IP/network union to intervals, remove whitelist/protected ranges,
    # then collapse again. This never widens a blocked range.
    intervals = [(int(n.network_address), int(n.broadcast_address)) for n in accepted_networks]
    intervals = merge_intervals(intervals)
    remaining = []
    for interval in intervals:
        remaining.extend(subtract_intervals(interval, exclusions))
    out_networks = []
    for start, end in remaining:
        out_networks.extend(ipaddress.summarize_address_range(ipaddress.IPv4Address(start), ipaddress.IPv4Address(end)))
    out_networks = list(ipaddress.collapse_addresses(out_networks)) if out_networks else []
    auto_pairs = [(int(n.network_address), int(n.broadcast_address)) for n in out_networks]
    if len(auto_pairs) > max_auto:
        raise RuntimeError("排除白名单后自动规则仍超过上限：%s > %s" % (len(auto_pairs), max_auto))
    return auto_pairs, included_sources, skipped_sources


def make_state(manual_pairs, final_pairs, source_state, config, previous_state, backup_path):
    return {
        "schema_version": 1,
        "version": VERSION,
        "updated_at": iso_now(),
        "manual_ranges": [[a, b] for a, b in manual_pairs],
        "last_written_ranges": [[a, b] for a, b in final_pairs],
        "sources": source_state,
        "last_backup": backup_path or (previous_state or {}).get("last_backup"),
        "waf_blacklist_path": config["waf"]["blacklist_path"],
    }


def run_command(command, logger):
    logger.info("执行：%s", " ".join(command))
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    output = (result.stdout or "").strip()
    if output:
        for line in output.splitlines()[-30:]:
            logger.info("%s", line)
    if result.returncode != 0:
        raise RuntimeError("命令执行失败（退出码 %s）：%s" % (result.returncode, " ".join(command)))
    return output


def atomic_restore(source, destination):
    destination = Path(destination)
    fd, temp_path = tempfile.mkstemp(prefix=destination.name + ".restore.", dir=str(destination.parent))
    os.close(fd)
    try:
        shutil.copy2(source, temp_path)
        os.replace(temp_path, str(destination))
    finally:
        try:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
        except OSError:
            pass


def make_backup(path, backup_dir):
    Path(backup_dir).mkdir(parents=True, exist_ok=True)
    stamp = utc_now().strftime("%Y%m%dT%H%M%SZ")
    destination = os.path.join(backup_dir, "ip_black.json.%s.bak" % stamp)
    suffix = 1
    while os.path.exists(destination):
        destination = os.path.join(backup_dir, "ip_black.json.%s.%s.bak" % (stamp, suffix))
        suffix += 1
    shutil.copy2(path, destination)
    return destination


def prepare(config, state, logger):
    waf_path = config["waf"]["blacklist_path"]
    white_path = config["waf"]["whitelist_path"]
    current_pairs = parse_waf_file(waf_path)
    whitelist_pairs = parse_waf_file(white_path)
    manual_pairs = build_manual_rules(current_pairs, state, logger)
    source_networks, new_source_state, reports, failures = collect_sources(config, state or {}, logger)
    if failures:
        raise RuntimeError("必需情报源不可用，拒绝写入：" + "；".join(failures))
    auto_pairs, included, skipped = make_auto_pairs(source_networks, config, whitelist_pairs, logger)
    final_pairs = dedupe_pairs(manual_pairs + auto_pairs)
    max_total = int(config["policy"].get("max_total_rules", 60000))
    if len(final_pairs) > max_total:
        raise RuntimeError("最终规则总数 %s 超过安全上限 %s，拒绝写入" % (len(final_pairs), max_total))

    # Verify the WAF's array endpoints can represent every output range.
    encoded = encode_pairs(final_pairs)
    for index, rule in enumerate(encoded):
        waf_rule_to_pair(rule, index)

    report = {
        "existing_rules": len(current_pairs),
        "manual_rules": len(manual_pairs),
        "whitelist_rules": len(whitelist_pairs),
        "auto_rules": len(auto_pairs),
        "final_rules": len(final_pairs),
        "included_sources": included,
        "skipped_sources": skipped,
        "sources": reports,
        "data": encoded,
        "final_pairs": final_pairs,
        "manual_pairs": manual_pairs,
        "source_state": new_source_state,
    }
    return report


def apply_changes(config, state_path, state, report, logger):
    waf_path = config["waf"]["blacklist_path"]
    nginx_bin = config["waf"].get("nginx_binary", "/www/server/nginx/sbin/nginx")
    backup_dir = config["paths"]["backup_dir"]
    state_path = str(state_path)
    old_blacklist = read_json(waf_path)
    new_blacklist = report["data"]
    old_state_exists = os.path.exists(state_path)
    old_state_raw = None
    if old_state_exists:
        with open(state_path, "rb") as handle:
            old_state_raw = handle.read()
    old_mode = file_mode(waf_path, 0o666)
    state_mode = file_mode(state_path, 0o600)

    if old_blacklist == new_blacklist:
        logger.info("黑名单内容没有变化，不触发 Nginx reload")
        new_state = make_state(report["manual_pairs"], report["final_pairs"], report["source_state"], config, state, None)
        write_json_atomic(state_path, new_state, state_mode)
        return False

    backup_path = make_backup(waf_path, backup_dir)
    state_backup = None
    if old_state_exists:
        state_backup = make_backup(state_path, backup_dir)
    new_state = make_state(report["manual_pairs"], report["final_pairs"], report["source_state"], config, state, backup_path)

    try:
        write_json_atomic(waf_path, new_blacklist, old_mode)
        write_json_atomic(state_path, new_state, state_mode)
        run_command([nginx_bin, "-t"], logger)
        run_command([nginx_bin, "-s", "reload"], logger)
        logger.info("同步成功：黑名单 %s 条；备份：%s", len(new_blacklist), backup_path)
        return True
    except Exception:
        logger.exception("应用失败，正在恢复原始黑名单和状态文件")
        atomic_restore(backup_path, waf_path)
        if state_backup:
            atomic_restore(state_backup, state_path)
        elif old_state_raw is not None:
            fd, tmp = tempfile.mkstemp(prefix="state.restore.", dir=str(Path(state_path).parent))
            with os.fdopen(fd, "wb") as handle:
                handle.write(old_state_raw)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, state_path)
        else:
            try:
                os.unlink(state_path)
            except OSError:
                pass
        try:
            run_command([nginx_bin, "-t"], logger)
            run_command([nginx_bin, "-s", "reload"], logger)
            logger.warning("已恢复原文件并重新加载 Nginx")
        except Exception:
            logger.exception("自动恢复后 Nginx 检查/重载仍失败，请立即检查服务")
        raise


def load_state(path):
    if not os.path.exists(path):
        return {}
    state = read_json(path)
    if not isinstance(state, dict):
        raise ValueError("状态文件不是 JSON 对象：%s" % path)
    if state.get("schema_version") != 1:
        raise ValueError("状态文件版本不兼容，请先备份后处理：%s" % path)
    return state


def rollback(config, state_path, state, logger):
    backup = (state or {}).get("last_backup")
    if not backup or not os.path.isfile(backup):
        raise RuntimeError("状态文件没有可用的 last_backup 记录")
    waf_path = config["waf"]["blacklist_path"]
    current_backup = make_backup(waf_path, config["paths"]["backup_dir"])
    atomic_restore(backup, waf_path)
    try:
        run_command([config["waf"].get("nginx_binary", "/www/server/nginx/sbin/nginx"), "-t"], logger)
        run_command([config["waf"].get("nginx_binary", "/www/server/nginx/sbin/nginx"), "-s", "reload"], logger)
        logger.warning("已回滚到：%s；回滚前文件备份：%s", backup, current_backup)
    except Exception:
        atomic_restore(current_backup, waf_path)
        raise


def status(config, state, logger):
    waf_path = config["waf"]["blacklist_path"]
    white_path = config["waf"]["whitelist_path"]
    black_count = len(parse_waf_file(waf_path))
    white_count = len(parse_waf_file(white_path))
    print("版本：", VERSION)
    print("黑名单：", waf_path, "记录：", black_count)
    print("白名单：", white_path, "记录：", white_count, "（只读，不会被同步器修改）")
    print("最近同步：", state.get("updated_at", "尚未同步"))
    print("最近备份：", state.get("last_backup", "无"))
    for sid, source in state.get("sources", {}).items():
        age = "未知"
        last = parse_iso(source.get("last_success"))
        if last:
            age = "%.1f 小时前" % max(0.0, (utc_now() - last).total_seconds() / 3600.0)
        print("来源：%s | %s | %s 条 | %s" % (sid, age, len(source.get("networks", [])), source.get("url", "")))


def self_test():
    sample = [[[192, 168, 10, 2], [192, 168, 10, 2]], [[192, 168, 10, 1], [192, 168, 10, 1]]]
    pairs = [waf_rule_to_pair(item, i) for i, item in enumerate(sample)]
    assert len(pairs) == 2
    cidrs = list(ipaddress.summarize_address_range(ipaddress.IPv4Address("192.168.10.1"), ipaddress.IPv4Address("192.168.10.2")))
    assert len(cidrs) == 2 and all(net.prefixlen == 32 for net in cidrs)
    demo = "# comment\n192.0.2.1\n8.8.8.8\n10.1.2.3\n203.0.113.9\n1.2.3.0/24\n"
    parsed, stats = normalize_feed_text(demo, "self-test", {"min_prefix_length": 20, "max_entries_per_source": 100})
    assert "8.8.8.8/32" in parsed
    assert "1.2.3.0/24" in parsed
    assert "10.1.2.3/32" not in parsed
    assert "192.0.2.1/32" not in parsed
    blocked = merge_intervals([(int(ipaddress.IPv4Address("8.8.8.0")), int(ipaddress.IPv4Address("8.8.8.255")))])
    rest = subtract_intervals(blocked[0], [(int(ipaddress.IPv4Address("8.8.8.10")), int(ipaddress.IPv4Address("8.8.8.10")))])
    assert sum(b - a + 1 for a, b in rest) == 255
    print("自检通过：WAF格式、CIDR处理、非公网过滤、白名单区间排除均正常。")


def main():
    parser = argparse.ArgumentParser(description="旧版宝塔 free_waf 全球 IPv4 威胁情报同步器")
    parser.add_argument("--config", default=DEFAULT_CONFIG, help="配置文件路径")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--apply", action="store_true", help="正式写入黑名单并在 nginx -t 通过后平滑 reload")
    group.add_argument("--status", action="store_true", help="显示当前状态")
    group.add_argument("--rollback", action="store_true", help="回滚到上一次同步前的黑名单")
    parser.add_argument("--self-test", action="store_true", help="运行本地格式与过滤自检")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        return 0

    config = load_config(args.config)
    paths = config["paths"]
    for key in ("state_file", "log_file", "lock_file", "backup_dir"):
        if key not in paths:
            raise ValueError("配置 paths 缺少 %s" % key)
    logger = setup_logging(paths["log_file"])
    Path(paths["state_file"]).parent.mkdir(parents=True, exist_ok=True)
    Path(paths["lock_file"]).parent.mkdir(parents=True, exist_ok=True)

    with open(paths["lock_file"], "a+") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            logger.error("已有同步任务正在运行，退出")
            return 2

        state = load_state(paths["state_file"])
        if args.status:
            status(config, state, logger)
            return 0
        if args.rollback:
            rollback(config, paths["state_file"], state, logger)
            return 0

        if os.geteuid() != 0 and args.apply:
            raise RuntimeError("正式写入及 Nginx reload 必须由 root 执行")

        logger.info("开始运行 Free WAF Threat Intelligence Sync %s；模式：%s", VERSION, "正式应用" if args.apply else "模拟运行")
        report = prepare(config, state, logger)
        print("\n========== 同步预览 ==========")
        print("现有黑名单：%s 条" % report["existing_rules"])
        print("识别并保留的人工规则：%s 条" % report["manual_rules"])
        print("白名单：%s 条（未修改；已从外部来源中排除重叠地址）" % report["whitelist_rules"])
        print("新增情报规则：%s 条" % report["auto_rules"])
        print("预计最终黑名单：%s 条" % report["final_rules"])
        print("纳入来源：%s" % (", ".join(report["included_sources"]) or "无"))
        for item in report["sources"]:
            print("- {name}: {status}; accepted={accepted}".format(**item))
            if item.get("error"):
                print("  原因：" + item["error"])
        if report["skipped_sources"]:
            print("因自动规则数量上限而跳过：", report["skipped_sources"])
        print("==============================\n")

        if not args.apply:
            logger.info("模拟运行结束：没有修改 WAF 文件，没有 reload Nginx")
            return 0

        changed = apply_changes(config, paths["state_file"], state, report, logger)
        if changed:
            print("正式同步完成：黑名单已更新，Nginx 已执行平滑 reload。")
        else:
            print("同步完成：名单无变化，只更新了情报状态；未 reload Nginx。")
        return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n用户中断", file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print("错误：%s" % exc, file=sys.stderr)
        sys.exit(1)
